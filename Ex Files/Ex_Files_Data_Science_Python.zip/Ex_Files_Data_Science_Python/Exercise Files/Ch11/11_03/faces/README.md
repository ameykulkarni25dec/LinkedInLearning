# Faces

Demo git repository

We're going to create the best face recognition software there is (even for people with glasses).

---
Miki Tebeka <miki@353solution.com>
